const {signUp} = require("../controllers/users.createUser.js")


module.exports = function(fastify){
    fastify.addHook("preHandler", signUp);
    fastify.post("/signup", async (req, resp) => {
        resp.send({message: `Успешная регистрация, ${JSON.stringify(req.body).split("\"")[3]}`});
    });
}
const {sighIn} = require("../controllers/users.createJWT.js");


const validsignIn = {
    type: "object",
    properties: {
        login: {type: "string"},
        password: {type: "string"}
    },
    required: ["login", "password"],
};


module.exports = function(fastify){
    fastify.addHook("preHandler", sighIn);
    fastify.post(
        "/sighin",  
        {schema:{
            body: validsignIn
        },
    },
    async(req, resp)=>{
        resp.send({message: `С возвращением`});
    })
}
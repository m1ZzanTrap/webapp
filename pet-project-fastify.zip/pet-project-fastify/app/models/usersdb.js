const {Sequelize} = require("sequelize");


module.exports = (sequelize) => {
    const User = sequelize.define("users",{
          id: {
              type: Sequelize.DataTypes.INTEGER,
              primaryKey: true,
              autoIncrement: true
          }, 
          login: {
              type: Sequelize.DataTypes.STRING, 
              allowNull: false,
              unique: true  
          }, 
          password: {
              type: Sequelize.DataTypes.STRING, 
              allowNull: false
          },
          email: {
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
              unique: true,
              defaultValue: ' '
          },
          firstname: {
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
          },
          lastname: {
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
          },
          phone: {
              type: Sequelize.DataTypes.STRING,
              allowNull: true,
              unique: true,
          },
      },   
      {
          timestamps: false,
      });
      
     return User;
  }
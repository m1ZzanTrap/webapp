const settings = require("../../configurations/dbconfig.js");


const Sequelize = require("sequelize");
const sequelize = new Sequelize(
    settings.db_settings.database,
    settings.db_settings.user,
    settings.db_settings.password,
    {
        host: settings.db_settings.host,
        dialect: settings.db_settings.dialect
    }
);



const db = {};


db.Sequelize = Sequelize;
db.sequelize = sequelize;


db.user = require("./usersdb.js")(sequelize, Sequelize);


module.exports = db;
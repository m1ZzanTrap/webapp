const db = require("../models/.");
const User = db.user;



exports.validRegistration = async(req, resp) => {
    const validSighUp = {
        
    }
    fastify.addHook("preValidation", async)
}
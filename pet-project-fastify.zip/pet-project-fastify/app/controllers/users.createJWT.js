const db = require("../models/.");
sequelize = db.sequelize;
Sequelize = db.Sequelize;



const bCrypt = require("bcrypt");

exports.sighIn = async(req, resp) => {
    try{
        const checkUser = await db.user.findOne({
            where: {
                login: JSON.stringify(req.body).split("\"")[3],
            }
        })

        if(!checkUser){
            return resp.code(404).send({message: "Нет такого пользователя"});
        };
        
        const validPasswd = bCrypt.compareSync(JSON.stringify(req.body).split("\"")[7], checkUser.password);
        

        if(!validPasswd){
            return resp.code(401).send({message: "Неверный пароль"});
        }

        const token = await fastify.jwt.sign({id: checkUser.id, algorithm: "HS256"})

        console.log("token" + token);

        resp.setCookie("token", token, {path: "/", httpOnly: true});
        return {success: true, token: token};
    }catch(e){
        console.log(e);
        return resp.code(500).send({error: e});
    }
};


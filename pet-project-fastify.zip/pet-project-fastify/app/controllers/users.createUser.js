const db = require("../models");
const User = db.user;



const bCrypt = require("bcrypt");


exports.signUp = async(req, resp) => {
    try{
        const CreateUser = await User.create({
            login: JSON.stringify(req.body).split("\"")[3], 
            password: bCrypt.hashSync(JSON.stringify(req.body).split("\"")[7], 8),
            email: JSON.stringify(req.body).split("\"")[11],
        });

        if(!CreateUser) resp.BadRequest().send({message: "Неправильный запрос"});
        return resp.code(200).send();

    }catch(e){
        console.log(e);
        return resp.code(500).send({error: e});
    }
};

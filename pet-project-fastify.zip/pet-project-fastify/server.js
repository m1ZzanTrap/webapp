const fastify = require("fastify")({logger:true});
const fastifyJWT = require("@fastify/jwt").fastifyJwt;
const cookie = require("@fastify/cookie").fastifyCookie;



const db = require("./app/models/.");



fastify.register(require("@fastify/formbody").fastifyFormbody);
fastify.register(fastifyJWT, {secret: "AbDuladfGsyun123inc"});
fastify.register(cookie);



require("./app/routes/users.SignUp.js")(fastify);
require("./app/routes/users.SignIn.js")(fastify);


const start = async() => {
    try {
        await fastify.listen({port: 3000});
    } catch (err) {
        console.log(err);
        process.exit(1);
    }
}

start();
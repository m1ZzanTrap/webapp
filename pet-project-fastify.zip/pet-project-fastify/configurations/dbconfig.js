const conf = {
    db_settings: {
        database: "project",
        user: "market",
        password: "qweasd123", 
        host: "localhost",
        dialect: "mariadb"    
    }
};


module.exports = conf;